import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FormlyFormOptions, FormlyFieldConfig, FormlyModule } from '@ngx-formly/core';
import { MatStepperModule } from '@angular/material/stepper';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatChipsModule } from '@angular/material/chips';
import { MatChipListbox } from '@angular/material/chips';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-guided-interview',
  imports: [
    CommonModule,
    MatStepperModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatProgressBarModule,
    FormlyModule,
    ReactiveFormsModule,
    MatChipsModule,
    MatChipListbox
  ],
  templateUrl: './guided-interview.html',
  styleUrl: './guided-interview.scss'
})
export class GuidedInterview implements OnInit {
  @Input() interviewConfig: any;

  forms: FormGroup[] = [];
  models: any[] = [];
  options: FormlyFormOptions[] = [];
  fields: FormlyFieldConfig[][] = [];
  showThankYou = false;

  async ngOnInit() {
    if (this.interviewConfig?.steps) {
      for (let index = 0; index < this.interviewConfig.steps.length; index++) {
        const step = this.interviewConfig.steps[index];
        this.forms[index] = new FormGroup({});
        this.models[index] = {};
        this.options[index] = {};

        if (step.fieldsRef) {
          // Load fields from reference
          const fieldsModule = await import(`../interviews/${step.fieldsRef}.json`);
          this.fields[index] = fieldsModule.default;
        } else {
          this.fields[index] = step.fields;
        }
      }
    }
  }

  getFieldsForReview(step: any, stepIndex: number): any[] {
    const fields: any[] = [];

    const extractFields = (fieldArray: any[]) => {
      fieldArray.forEach(field => {
        if (field.fieldGroup) {
          extractFields(field.fieldGroup);
        } else if (field.key && field.props?.label) {
          fields.push({
            key: field.key,
            label: field.props.label,
            type: field.type
          });
        }
      });
    };

    if (this.fields[stepIndex]) {
      extractFields(this.fields[stepIndex]);
    }

    return fields;
  }

  getFieldValue(key: string, stepIndex: number): string {
    const value = this.models[stepIndex][key];

    if (value === null || value === undefined) {
      return 'Not provided';
    }

    if (typeof value === 'boolean') {
      return value ? 'Yes' : 'No';
    }

    if (value instanceof Date) {
      return value.toLocaleDateString();
    }

    return value.toString();
  }

  onSubmit() {
    const allValid = this.forms.every(form => form.valid);
    if (allValid) {
      const formData = this.models.reduce((acc, model, index) => {
        acc[`step${index + 1}`] = model;
        return acc;
      }, {});
      console.log('Form submitted:', formData);
      this.showThankYou = true;
    }
  }

  resetInterview() {
    this.showThankYou = false;
    this.forms.forEach(form => form.reset());
    this.models = this.models.map(() => ({}));
  }
}