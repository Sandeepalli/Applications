import {
  matFormFieldAnimations
} from "./chunk-I3DSRTVY.js";
import {
  MatFormFieldModule
} from "./chunk-QENVTLW7.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-ZFN77XUH.js";
import "./chunk-FTJHLKHI.js";
import "./chunk-5NJVVZ3V.js";
import "./chunk-HBUVWOLH.js";
import "./chunk-R7S4VBDJ.js";
import "./chunk-EOFW2REK.js";
import "./chunk-FLC5GOMY.js";
import "./chunk-UIWETAEJ.js";
import "./chunk-P2NQ2BEM.js";
import "./chunk-JYZKPBDK.js";
import "./chunk-CNF4NAGG.js";
import "./chunk-R2QGWZ7S.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations
};
