import {
  MAT_NATIVE_DATE_FORMATS,
  MAT_OPTGROUP,
  MAT_OPTION_PARENT_COMPONENT,
  MatLine,
  MatLineModule,
  MatNativeDateModule,
  MatOptgroup,
  MatOption,
  MatOptionModule,
  MatOptionSelectionChange,
  MatPseudoCheckbox,
  MatPseudoCheckboxModule,
  NativeDateAdapter,
  NativeDateModule,
  VERSION,
  _MatInternalFormField,
  _countGroupLabelsBeforeOption,
  _getOptionScrollPosition,
  provideNativeDateAdapter,
  setLines
} from "./chunk-GKQHDVKV.js";
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MAT_DATE_LOCALE_FACTORY
} from "./chunk-NLJJEW45.js";
import {
  _ErrorStateTracker
} from "./chunk-JKRSZR5T.js";
import {
  ErrorStateMatcher,
  ShowOnDirtyErrorStateMatcher
} from "./chunk-OY76RGOO.js";
import {
  MatRippleLoader
} from "./chunk-XF6RQVCE.js";
import {
  MatRippleModule
} from "./chunk-JQND4H7T.js";
import {
  MAT_RIPPLE_GLOBAL_OPTIONS,
  MatRipple,
  RippleRef,
  RippleRenderer,
  RippleState,
  _StructuralStylesLoader,
  defaultRippleAnimationConfig
} from "./chunk-MP2HXK26.js";
import {
  AnimationCurves,
  AnimationDurations,
  MATERIAL_ANIMATIONS,
  _animationsDisabled
} from "./chunk-5NJVVZ3V.js";
import "./chunk-HBUVWOLH.js";
import {
  MATERIAL_SANITY_CHECKS,
  MatCommonModule
} from "./chunk-R7S4VBDJ.js";
import "./chunk-EOFW2REK.js";
import "./chunk-FLC5GOMY.js";
import "./chunk-UIWETAEJ.js";
import "./chunk-P2NQ2BEM.js";
import "./chunk-JYZKPBDK.js";
import "./chunk-CNF4NAGG.js";
import "./chunk-R2QGWZ7S.js";
export {
  AnimationCurves,
  AnimationDurations,
  DateAdapter,
  ErrorStateMatcher,
  MATERIAL_ANIMATIONS,
  MATERIAL_SANITY_CHECKS,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MAT_DATE_LOCALE_FACTORY,
  MAT_NATIVE_DATE_FORMATS,
  MAT_OPTGROUP,
  MAT_OPTION_PARENT_COMPONENT,
  MAT_RIPPLE_GLOBAL_OPTIONS,
  MatCommonModule,
  MatLine,
  MatLineModule,
  MatNativeDateModule,
  MatOptgroup,
  MatOption,
  MatOptionModule,
  MatOptionSelectionChange,
  MatPseudoCheckbox,
  MatPseudoCheckboxModule,
  MatRipple,
  MatRippleLoader,
  MatRippleModule,
  NativeDateAdapter,
  NativeDateModule,
  RippleRef,
  RippleRenderer,
  RippleState,
  ShowOnDirtyErrorStateMatcher,
  VERSION,
  _ErrorStateTracker,
  _MatInternalFormField,
  _StructuralStylesLoader,
  _animationsDisabled,
  _countGroupLabelsBeforeOption,
  _getOptionScrollPosition,
  defaultRippleAnimationConfig,
  provideNativeDateAdapter,
  setLines
};
