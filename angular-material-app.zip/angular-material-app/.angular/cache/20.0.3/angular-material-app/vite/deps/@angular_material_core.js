import {
  MAT_NATIVE_DATE_FORMATS,
  MAT_OPTGROUP,
  MAT_OPTION_PARENT_COMPONENT,
  MatLine,
  MatLineModule,
  MatNativeDateModule,
  MatOptgroup,
  MatOption,
  MatOptionModule,
  MatOptionSelectionChange,
  MatPseudoCheckbox,
  MatPseudoCheckboxModule,
  NativeDateAdapter,
  NativeDateModule,
  VERSION,
  _MatInternalFormField,
  _countGroupLabelsBeforeOption,
  _getOptionScrollPosition,
  provideNativeDateAdapter,
  setLines
} from "./chunk-FH747WTX.js";
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MAT_DATE_LOCALE_FACTORY
} from "./chunk-NLJJEW45.js";
import {
  _ErrorStateTracker
} from "./chunk-JKRSZR5T.js";
import {
  ErrorStateMatcher,
  ShowOnDirtyErrorStateMatcher
} from "./chunk-OY76RGOO.js";
import {
  MatRippleLoader
} from "./chunk-S3L32MHF.js";
import {
  MatRippleModule
} from "./chunk-O4ZUAF4A.js";
import {
  MAT_RIPPLE_GLOBAL_OPTIONS,
  MatRipple,
  RippleRef,
  RippleRenderer,
  RippleState,
  _StructuralStylesLoader,
  defaultRippleAnimationConfig
} from "./chunk-OCOIQB7E.js";
import "./chunk-DQ7OVFPD.js";
import "./chunk-HBUVWOLH.js";
import "./chunk-EOFW2REK.js";
import {
  AnimationCurves,
  AnimationDurations,
  MATERIAL_ANIMATIONS,
  _animationsDisabled
} from "./chunk-BYBIAFOH.js";
import {
  MATERIAL_SANITY_CHECKS,
  MatCommonModule
} from "./chunk-2SL7JEXV.js";
import "./chunk-FLC5GOMY.js";
import "./chunk-UIWETAEJ.js";
import "./chunk-7FHGXOD6.js";
import "./chunk-JYZKPBDK.js";
import "./chunk-CNF4NAGG.js";
import "./chunk-R2QGWZ7S.js";
export {
  AnimationCurves,
  AnimationDurations,
  DateAdapter,
  ErrorStateMatcher,
  MATERIAL_ANIMATIONS,
  MATERIAL_SANITY_CHECKS,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MAT_DATE_LOCALE_FACTORY,
  MAT_NATIVE_DATE_FORMATS,
  MAT_OPTGROUP,
  MAT_OPTION_PARENT_COMPONENT,
  MAT_RIPPLE_GLOBAL_OPTIONS,
  MatCommonModule,
  MatLine,
  MatLineModule,
  MatNativeDateModule,
  MatOptgroup,
  MatOption,
  MatOptionModule,
  MatOptionSelectionChange,
  MatPseudoCheckbox,
  MatPseudoCheckboxModule,
  MatRipple,
  MatRippleLoader,
  MatRippleModule,
  NativeDateAdapter,
  NativeDateModule,
  RippleRef,
  RippleRenderer,
  RippleState,
  ShowOnDirtyErrorStateMatcher,
  VERSION,
  _ErrorStateTracker,
  _MatInternalFormField,
  _StructuralStylesLoader,
  _animationsDisabled,
  _countGroupLabelsBeforeOption,
  _getOptionScrollPosition,
  defaultRippleAnimationConfig,
  provideNativeDateAdapter,
  setLines
};
