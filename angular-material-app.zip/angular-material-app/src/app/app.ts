import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { GuidedInterview } from './guided-interview/guided-interview';

import guidedInterview1 from './interviews/guided-interview.json';
import guidedInterview2 from './interviews/guided-interview2.json';
import guidedInterview3 from './interviews/guided-interview3.json';
import guidedInterview4 from './interviews/guided-interview4.json';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, MatToolbarModule, MatButtonModule, MatCardModule, MatIconModule, MatTabsModule, GuidedInterview],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  protected title = 'Guided Interview Framework';
  
  interviews = {
    registration: guidedInterview1,
    onboarding: guidedInterview2,
    feedback: guidedInterview3,
    legal: guidedInterview4
  };
}
